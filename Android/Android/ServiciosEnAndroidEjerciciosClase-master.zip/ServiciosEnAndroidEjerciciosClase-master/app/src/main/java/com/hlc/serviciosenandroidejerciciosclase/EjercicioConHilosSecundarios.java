package com.hlc.serviciosenandroidejerciciosclase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class EjercicioConHilosSecundarios extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio_con_hilos_secundarios);
    }
}
