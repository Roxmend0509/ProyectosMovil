AQua Movil
=============
[![AQua Movil](https://raw.githubusercontent.com/jamper91/Servicios/master/Aplicacion%20Movil/res/drawable-hdpi/logo.png)]()

Aplicacion para la toma de lectura de servicios publicos

Paquetes
-------

Los siguiente paquetes hacen parte dle proyecto

* Administrador: Se encarga de cargar archivos, generar archivos, agregar parametros y ver informes
* Base: contiene funciones comunes para todas las claves, ademas de contener el archivo de la base de datos	
* Lector: Archivos para que los roles de lectores puedan tomar lecturas
