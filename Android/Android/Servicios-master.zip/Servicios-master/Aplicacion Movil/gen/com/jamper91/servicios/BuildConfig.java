/** Automatically generated file. DO NOT MODIFY */
package com.jamper91.servicios;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}